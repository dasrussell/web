function modelInformation(){
    let km = document.getElementById('modelKm').value;
    let modeloAuto = document.getElementById('modelSelection').value;
    let modelYear = document.getElementById('modelYear').value;

    alert(km + " Km " + modeloAuto + " " + modelYear);
}

